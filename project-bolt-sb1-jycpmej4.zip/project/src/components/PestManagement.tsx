import React, { useState } from 'react';
import { Bug, Camera, Search, AlertTriangle, Shield, Leaf, Zap, Upload, X, CheckCircle } from 'lucide-react';

interface Pest {
  id: string;
  name: string;
  type: string;
  severity: 'low' | 'medium' | 'high';
  crops: string[];
  symptoms: string[];
  treatment: string[];
  prevention: string[];
  image: string;
}

const PestManagement: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPest, setSelectedPest] = useState<Pest | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);

  const pests: Pest[] = [
    {
      id: '1',
      name: 'Aphids',
      type: 'Insect',
      severity: 'medium',
      crops: ['Wheat', 'Barley', 'Mustard', 'Vegetables'],
      symptoms: [
        'Small, soft-bodied insects on leaves and stems',
        'Yellowing and curling of leaves',
        'Sticky honeydew secretion',
        'Stunted plant growth',
      ],
      treatment: [
        'Spray insecticidal soap solution',
        'Use neem oil application',
        'Release ladybugs as biological control',
        'Apply systemic insecticides if severe',
      ],
      prevention: [
        'Maintain proper plant spacing',
        'Remove weed hosts around fields',
        'Use reflective mulches',
        'Regular monitoring and early detection',
      ],
      image: 'https://images.pexels.com/photos/4750270/pexels-photo-4750270.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    },
    {
      id: '2',
      name: 'Bollworm',
      type: 'Larva',
      severity: 'high',
      crops: ['Cotton', 'Tomato', 'Corn', 'Chickpea'],
      symptoms: [
        'Holes in leaves, buds, and fruits',
        'Frass (insect droppings) near feeding sites',
        'Damaged bolls or fruits',
        'Caterpillar larvae visible on plants',
      ],
      treatment: [
        'Apply Bt-based insecticides',
        'Use pheromone traps',
        'Spray synthetic pyrethroids',
        'Hand picking of larvae when possible',
      ],
      prevention: [
        'Plant Bt cotton varieties',
        'Maintain trap crops around main field',
        'Regular field scouting',
        'Proper crop rotation practices',
      ],
      image: 'https://images.pexels.com/photos/4750271/pexels-photo-4750271.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    },
    {
      id: '3',
      name: 'Late Blight',
      type: 'Fungal Disease',
      severity: 'high',
      crops: ['Potato', 'Tomato'],
      symptoms: [
        'Dark brown patches on leaves',
        'White fungal growth on leaf undersides',
        'Black streaks on stems',
        'Rotting of fruits and tubers',
      ],
      treatment: [
        'Apply copper-based fungicides',
        'Use systemic fungicides like mancozeb',
        'Remove and destroy infected plants',
        'Improve air circulation around plants',
      ],
      prevention: [
        'Plant disease-resistant varieties',
        'Avoid overhead irrigation',
        'Ensure proper field drainage',
        'Apply preventive fungicide sprays',
      ],
      image: 'https://images.pexels.com/photos/4750272/pexels-photo-4750272.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    },
  ];

  const crops = ['All Crops', 'Wheat', 'Rice', 'Cotton', 'Tomato', 'Potato', 'Corn', 'Vegetables'];

  const filteredPests = pests.filter((pest) => {
    const matchesCrop = selectedCrop === '' || selectedCrop === 'All Crops' || pest.crops.includes(selectedCrop);
    const matchesSearch = searchTerm === '' || pest.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCrop && matchesSearch;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-green-100 text-green-700 border-green-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-4 w-4" />;
      case 'medium':
        return <Bug className="h-4 w-4" />;
      default:
        return <Shield className="h-4 w-4" />;
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setUploadedImage(imageUrl);
        analyzeImage(imageUrl, file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = (imageUrl: string, fileName: string) => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis with realistic delay and results
    setTimeout(() => {
      const analysisResults = generateAIAnalysis(fileName);
      setAnalysisResult(analysisResults);
      setIsAnalyzing(false);
    }, 3000);
  };

  const generateAIAnalysis = (fileName: string) => {
    // Simulate AI analysis based on filename or random selection
    const possiblePests = [
      {
        identified: 'Aphids',
        confidence: 92,
        severity: 'medium',
        affectedCrops: ['Wheat', 'Mustard', 'Vegetables'],
        symptoms: [
          'Small green/black insects clustered on leaves',
          'Sticky honeydew on plant surfaces',
          'Yellowing and curling of leaves',
          'Stunted plant growth'
        ],
        immediateActions: [
          'Spray with insecticidal soap solution (2 tbsp per liter)',
          'Apply neem oil in early morning or evening',
          'Remove heavily infested leaves',
          'Increase air circulation around plants'
        ],
        treatment: [
          'Use systemic insecticides like Imidacloprid if severe',
          'Release beneficial insects (ladybugs, lacewings)',
          'Apply reflective mulch to deter aphids',
          'Monitor weekly and repeat treatment if needed'
        ],
        prevention: [
          'Plant companion crops like marigolds',
          'Avoid over-fertilizing with nitrogen',
          'Maintain proper plant spacing',
          'Regular field inspection and early detection'
        ]
      },
      {
        identified: 'Leaf Blight',
        confidence: 88,
        severity: 'high',
        affectedCrops: ['Tomato', 'Potato', 'Pepper'],
        symptoms: [
          'Brown spots with yellow halos on leaves',
          'Rapid spreading during humid conditions',
          'Leaf yellowing and dropping',
          'Dark streaks on stems'
        ],
        immediateActions: [
          'Remove and destroy infected plant parts',
          'Apply copper-based fungicide immediately',
          'Improve air circulation around plants',
          'Avoid overhead watering'
        ],
        treatment: [
          'Use systemic fungicides like Mancozeb',
          'Apply fungicide every 7-10 days until controlled',
          'Ensure proper drainage in field',
          'Consider resistant varieties for next season'
        ],
        prevention: [
          'Plant disease-resistant varieties',
          'Maintain proper plant spacing',
          'Use drip irrigation instead of sprinklers',
          'Apply preventive fungicide sprays'
        ]
      },
      {
        identified: 'Whitefly',
        confidence: 85,
        severity: 'medium',
        affectedCrops: ['Cotton', 'Tomato', 'Okra', 'Brinjal'],
        symptoms: [
          'Small white flying insects on leaf undersides',
          'Yellow sticky traps catch many flies',
          'Yellowing of leaves',
          'Sooty mold on honeydew deposits'
        ],
        immediateActions: [
          'Install yellow sticky traps around field',
          'Spray with insecticidal soap solution',
          'Remove heavily infested lower leaves',
          'Apply neem oil spray in evening'
        ],
        treatment: [
          'Use systemic insecticides like Thiamethoxam',
          'Apply insecticide with spreader-sticker',
          'Target leaf undersides during spraying',
          'Rotate different classes of insecticides'
        ],
        prevention: [
          'Use reflective silver mulch',
          'Plant trap crops around main field',
          'Maintain field hygiene',
          'Regular monitoring with yellow traps'
        ]
      },
      {
        identified: 'Caterpillar (Bollworm)',
        confidence: 94,
        severity: 'high',
        affectedCrops: ['Cotton', 'Tomato', 'Corn', 'Chickpea'],
        symptoms: [
          'Holes in leaves, buds, and fruits',
          'Caterpillar larvae visible on plants',
          'Frass (droppings) near feeding sites',
          'Damaged bolls or fruits with entry holes'
        ],
        immediateActions: [
          'Hand-pick visible caterpillars',
          'Apply Bt-based insecticide immediately',
          'Install pheromone traps',
          'Remove damaged fruits and buds'
        ],
        treatment: [
          'Use Bt (Bacillus thuringiensis) spray',
          'Apply synthetic pyrethroids if severe',
          'Use nuclear polyhedrosis virus (NPV)',
          'Spray during early morning or evening'
        ],
        prevention: [
          'Plant Bt cotton/corn varieties',
          'Maintain trap crops (marigold, castor)',
          'Deep plowing after harvest',
          'Regular field scouting and monitoring'
        ]
      }
    ];

    // Select result based on filename hints or randomly
    let selectedResult;
    const filenameLower = fileName.toLowerCase();
    
    if (filenameLower.includes('aphid') || filenameLower.includes('green')) {
      selectedResult = possiblePests[0];
    } else if (filenameLower.includes('blight') || filenameLower.includes('spot')) {
      selectedResult = possiblePests[1];
    } else if (filenameLower.includes('white') || filenameLower.includes('fly')) {
      selectedResult = possiblePests[2];
    } else if (filenameLower.includes('caterpillar') || filenameLower.includes('worm')) {
      selectedResult = possiblePests[3];
    } else {
      // Random selection
      selectedResult = possiblePests[Math.floor(Math.random() * possiblePests.length)];
    }

    return selectedResult;
  };

  const resetAnalysis = () => {
    setUploadedImage(null);
    setAnalysisResult(null);
    setIsAnalyzing(false);
    setShowUploadModal(false);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Pest & Disease Management</h1>
        <p className="text-lg text-gray-600">Identify, treat, and prevent agricultural pests and diseases</p>
      </div>

      {/* AI Identification Tool */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl p-6 text-white">
        <div className="flex items-center space-x-3 mb-4">
          <Camera className="h-6 w-6" />
          <h2 className="text-xl font-semibold">AI Pest Identification</h2>
        </div>
        <p className="mb-4">Upload a photo of the affected plant for instant AI-powered identification and treatment recommendations.</p>
        <button 
          onClick={() => setShowUploadModal(true)}
          className="bg-white text-green-600 px-6 py-2 rounded-lg hover:bg-gray-100 transition-colors duration-200 font-medium flex items-center space-x-2"
        >
          <Upload className="h-4 w-4" />
          <span>Upload Photo</span>
        </button>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">AI Pest Identification</h2>
                <button
                  onClick={resetAnalysis}
                  className="text-gray-500 hover:text-gray-700 text-xl"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              {!uploadedImage ? (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Plant Photo</h3>
                  <p className="text-gray-600 mb-4">
                    Take a clear photo of the affected plant parts (leaves, stems, fruits) for accurate identification
                  </p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <label
                    htmlFor="image-upload"
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 cursor-pointer inline-flex items-center space-x-2"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Choose Photo</span>
                  </label>
                  <p className="text-sm text-gray-500 mt-2">Supports JPG, PNG, WebP formats</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="text-center">
                    <img
                      src={uploadedImage}
                      alt="Uploaded plant"
                      className="max-w-full h-64 object-contain mx-auto rounded-lg border"
                    />
                  </div>

                  {isAnalyzing ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Analyzing Image...</h3>
                      <p className="text-gray-600">Our AI is examining the plant for pests and diseases</p>
                    </div>
                  ) : analysisResult ? (
                    <div className="space-y-6">
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex items-center space-x-3 mb-3">
                          <CheckCircle className="h-6 w-6 text-green-600" />
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">
                              Identified: {analysisResult.identified}
                            </h3>
                            <p className="text-sm text-gray-600">
                              Confidence: {analysisResult.confidence}% • Severity: {analysisResult.severity.toUpperCase()}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {analysisResult.affectedCrops.map((crop: string, index: number) => (
                            <span key={index} className="px-2 py-1 bg-green-100 text-green-700 text-sm rounded">
                              {crop}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                            <Leaf className="h-5 w-5 text-red-500 mr-2" />
                            Symptoms Detected
                          </h4>
                          <ul className="space-y-2">
                            {analysisResult.symptoms.map((symptom: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-start">
                                <span className="w-1 h-1 bg-red-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                {symptom}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                            <AlertTriangle className="h-5 w-5 text-orange-500 mr-2" />
                            Immediate Actions
                          </h4>
                          <ul className="space-y-2">
                            {analysisResult.immediateActions.map((action: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-start">
                                <span className="w-1 h-1 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                            <Zap className="h-5 w-5 text-blue-500 mr-2" />
                            Treatment Plan
                          </h4>
                          <ul className="space-y-2">
                            {analysisResult.treatment.map((treatment: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-start">
                                <span className="w-1 h-1 bg-blue-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                {treatment}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                            <Shield className="h-5 w-5 text-green-500 mr-2" />
                            Prevention Tips
                          </h4>
                          <ul className="space-y-2">
                            {analysisResult.prevention.map((prevention: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-start">
                                <span className="w-1 h-1 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                {prevention}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="flex space-x-4">
                        <button
                          onClick={resetAnalysis}
                          className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200"
                        >
                          Analyze Another Photo
                        </button>
                        <button
                          onClick={() => setShowUploadModal(false)}
                          className="flex-1 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors duration-200"
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  ) : null}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Search Pest/Disease</label>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search for pests or diseases..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Crop</label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            >
              {crops.map((crop) => (
                <option key={crop} value={crop}>{crop}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Pest List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPests.map((pest) => (
          <div
            key={pest.id}
            onClick={() => setSelectedPest(pest)}
            className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <img
              src={pest.image}
              alt={pest.name}
              className="w-full h-40 object-cover rounded-lg mb-4"
            />
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold text-gray-900">{pest.name}</h3>
              <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(pest.severity)}`}>
                {getSeverityIcon(pest.severity)}
                <span>{pest.severity.toUpperCase()}</span>
              </span>
            </div>
            <p className="text-sm text-gray-600 mb-2">{pest.type}</p>
            <div className="flex flex-wrap gap-1">
              {pest.crops.slice(0, 3).map((crop, index) => (
                <span key={index} className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">
                  {crop}
                </span>
              ))}
              {pest.crops.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                  +{pest.crops.length - 3} more
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Detailed View Modal */}
      {selectedPest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{selectedPest.name}</h2>
                <button
                  onClick={() => setSelectedPest(null)}
                  className="text-gray-500 hover:text-gray-700 text-xl"
                >
                  ×
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <img
                    src={selectedPest.image}
                    alt={selectedPest.name}
                    className="w-full h-64 object-cover rounded-lg mb-4"
                  />
                  <div className="space-y-2">
                    <p><strong>Type:</strong> {selectedPest.type}</p>
                    <p>
                      <strong>Severity:</strong>{' '}
                      <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded text-sm ${getSeverityColor(selectedPest.severity)}`}>
                        {getSeverityIcon(selectedPest.severity)}
                        <span>{selectedPest.severity.toUpperCase()}</span>
                      </span>
                    </p>
                    <div>
                      <strong>Affected Crops:</strong>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedPest.crops.map((crop, index) => (
                          <span key={index} className="px-2 py-1 bg-green-100 text-green-700 text-sm rounded">
                            {crop}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                      <Leaf className="h-5 w-5 text-red-500 mr-2" />
                      Symptoms
                    </h3>
                    <ul className="space-y-1">
                      {selectedPest.symptoms.map((symptom, index) => (
                        <li key={index} className="text-sm text-gray-700 flex items-start">
                          <span className="w-1 h-1 bg-red-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                          {symptom}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                      <Zap className="h-5 w-5 text-orange-500 mr-2" />
                      Treatment
                    </h3>
                    <ul className="space-y-1">
                      {selectedPest.treatment.map((treatment, index) => (
                        <li key={index} className="text-sm text-gray-700 flex items-start">
                          <span className="w-1 h-1 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                          {treatment}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                      <Shield className="h-5 w-5 text-green-500 mr-2" />
                      Prevention
                    </h3>
                    <ul className="space-y-1">
                      {selectedPest.prevention.map((prevention, index) => (
                        <li key={index} className="text-sm text-gray-700 flex items-start">
                          <span className="w-1 h-1 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                          {prevention}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PestManagement;