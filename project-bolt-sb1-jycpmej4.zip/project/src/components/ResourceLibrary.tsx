import React, { useState } from 'react';
import { Book, Video, FileText, Download, Search, Filter, Star, Clock, User } from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  type: 'guide' | 'video' | 'article' | 'document';
  category: string;
  description: string;
  author: string;
  duration?: string;
  rating: number;
  downloads: number;
  image: string;
  tags: string[];
}

const ResourceLibrary: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  const resources: Resource[] = [
    {
      id: '1',
      title: 'Complete Guide to Organic Farming',
      type: 'guide',
      category: 'Organic Farming',
      description: 'Comprehensive guide covering all aspects of organic farming including soil preparation, pest management, and certification processes.',
      author: 'Dr. Sarah Johnson',
      rating: 4.8,
      downloads: 1250,
      image: 'https://images.pexels.com/photos/1458618/pexels-photo-1458618.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['organic', 'sustainable', 'certification', 'soil-health'],
    },
    {
      id: '2',
      title: 'Drip Irrigation System Setup',
      type: 'video',
      category: 'Irrigation',
      description: 'Step-by-step video tutorial on installing and maintaining an efficient drip irrigation system for maximum water conservation.',
      author: 'Farm Tech Solutions',
      duration: '25 minutes',
      rating: 4.6,
      downloads: 890,
      image: 'https://images.pexels.com/photos/1112080/pexels-photo-1112080.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['irrigation', 'water-conservation', 'technology', 'installation'],
    },
    {
      id: '3',
      title: 'Integrated Pest Management Strategies',
      type: 'article',
      category: 'Pest Control',
      description: 'Research-based article on implementing IPM practices to reduce pesticide use while maintaining crop health and yield.',
      author: 'Agricultural Research Institute',
      rating: 4.9,
      downloads: 2100,
      image: 'https://images.pexels.com/photos/4750270/pexels-photo-4750270.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['ipm', 'pest-control', 'sustainable', 'research'],
    },
    {
      id: '4',
      title: 'Soil Testing and Analysis Manual',
      type: 'document',
      category: 'Soil Management',
      description: 'Detailed manual on soil testing procedures, interpreting results, and making informed fertilization decisions.',
      author: 'Soil Science Association',
      rating: 4.7,
      downloads: 1580,
      image: 'https://images.pexels.com/photos/1072824/pexels-photo-1072824.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['soil-testing', 'fertilization', 'analysis', 'nutrients'],
    },
    {
      id: '5',
      title: 'Climate-Smart Agriculture Practices',
      type: 'guide',
      category: 'Climate Change',
      description: 'Guide to adapting farming practices for climate resilience and reducing greenhouse gas emissions from agriculture.',
      author: 'Climate Agriculture Network',
      rating: 4.5,
      downloads: 975,
      image: 'https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['climate-smart', 'adaptation', 'resilience', 'sustainability'],
    },
    {
      id: '6',
      title: 'Crop Rotation Planning Workshop',
      type: 'video',
      category: 'Crop Management',
      description: 'Interactive workshop on designing effective crop rotation systems for improved soil health and pest management.',
      author: 'Sustainable Farming Institute',
      duration: '45 minutes',
      rating: 4.8,
      downloads: 1320,
      image: 'https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
      tags: ['crop-rotation', 'planning', 'soil-health', 'workshop'],
    },
  ];

  const categories = ['all', 'Organic Farming', 'Irrigation', 'Pest Control', 'Soil Management', 'Climate Change', 'Crop Management'];
  const types = ['all', 'guide', 'video', 'article', 'document'];

  const filteredResources = resources.filter((resource) => {
    const matchesSearch = searchTerm === '' || 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    const matchesType = selectedType === 'all' || resource.type === selectedType;
    
    return matchesSearch && matchesCategory && matchesType;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'guide':
        return <Book className="h-4 w-4" />;
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'article':
        return <FileText className="h-4 w-4" />;
      case 'document':
        return <FileText className="h-4 w-4" />;
      default:
        return <Book className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'guide':
        return 'bg-green-100 text-green-700';
      case 'video':
        return 'bg-red-100 text-red-700';
      case 'article':
        return 'bg-blue-100 text-blue-700';
      case 'document':
        return 'bg-purple-100 text-purple-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Resource Library</h1>
        <p className="text-lg text-gray-600">Access comprehensive farming guides, videos, and research materials</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search resources, topics, or keywords..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              />
            </div>
          </div>
          <div className="flex gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                {types.map((type) => (
                  <option key={type} value={type}>
                    {type === 'all' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      <div className="flex items-center justify-between">
        <p className="text-gray-600">
          Found {filteredResources.length} resource{filteredResources.length !== 1 ? 's' : ''}
          {searchTerm && ` for "${searchTerm}"`}
        </p>
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-gray-400" />
          <span className="text-sm text-gray-500">Sort by: Most Popular</span>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => (
          <div key={resource.id} className="bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
            <img
              src={resource.image}
              alt={resource.title}
              className="w-full h-48 object-cover rounded-t-xl"
            />
            <div className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(resource.type)}`}>
                  {getTypeIcon(resource.type)}
                  <span>{resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}</span>
                </span>
                <span className="text-xs text-gray-500">{resource.category}</span>
              </div>
              
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{resource.title}</h3>
              <p className="text-sm text-gray-600 mb-4 line-clamp-3">{resource.description}</p>
              
              <div className="flex items-center space-x-2 mb-3">
                <User className="h-4 w-4 text-gray-400" />
                <span className="text-sm text-gray-600">{resource.author}</span>
                {resource.duration && (
                  <>
                    <Clock className="h-4 w-4 text-gray-400 ml-2" />
                    <span className="text-sm text-gray-600">{resource.duration}</span>
                  </>
                )}
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-1">
                  {renderStars(resource.rating)}
                  <span className="text-sm text-gray-600 ml-1">({resource.rating})</span>
                </div>
                <span className="text-sm text-gray-500">{resource.downloads} downloads</span>
              </div>
              
              <div className="flex flex-wrap gap-1 mb-4">
                {resource.tags.slice(0, 3).map((tag, index) => (
                  <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                    #{tag}
                  </span>
                ))}
                {resource.tags.length > 3 && (
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                    +{resource.tags.length - 3} more
                  </span>
                )}
              </div>
              
              <button className="w-full flex items-center justify-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200">
                <Download className="h-4 w-4" />
                <span>Access Resource</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredResources.length === 0 && (
        <div className="text-center py-12">
          <Book className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No resources found</h3>
          <p className="text-gray-600">Try adjusting your search terms or filters to find relevant resources.</p>
        </div>
      )}

      {/* Featured Collections */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl p-6 text-white">
        <h2 className="text-xl font-semibold mb-4">Featured Collections</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <Book className="h-8 w-8 mb-2" />
            <h3 className="font-semibold mb-1">Beginner's Guide</h3>
            <p className="text-sm opacity-90">Essential resources for new farmers</p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <Video className="h-8 w-8 mb-2" />
            <h3 className="font-semibold mb-1">Video Tutorials</h3>
            <p className="text-sm opacity-90">Step-by-step farming techniques</p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <FileText className="h-8 w-8 mb-2" />
            <h3 className="font-semibold mb-1">Research Papers</h3>
            <p className="text-sm opacity-90">Latest agricultural research findings</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceLibrary;