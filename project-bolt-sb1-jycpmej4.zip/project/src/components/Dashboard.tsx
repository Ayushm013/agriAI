import React from 'react';
import { Sprout, Cloud, Bug, Droplets, TrendingUp, Calendar, MessageCircle, Book, ArrowRight, AlertCircle, CheckCircle } from 'lucide-react';
import type { ViewType } from '../App';

interface DashboardProps {
  onNavigate: (view: ViewType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const quickStats = [
    { label: 'Active Recommendations', value: '12', color: 'text-green-600', bgColor: 'bg-green-100' },
    { label: 'Weather Alerts', value: '3', color: 'text-orange-600', bgColor: 'bg-orange-100' },
    { label: 'Pending Actions', value: '8', color: 'text-blue-600', bgColor: 'bg-blue-100' },
    { label: 'Crop Health Score', value: '87%', color: 'text-emerald-600', bgColor: 'bg-emerald-100' },
  ];

  const recentAlerts = [
    { type: 'warning', message: 'High humidity detected - Monitor for fungal diseases', time: '2 hours ago' },
    { type: 'info', message: 'Optimal planting window for winter wheat opens next week', time: '1 day ago' },
    { type: 'success', message: 'Irrigation schedule completed successfully', time: '2 days ago' },
  ];

  const actionCards = [
    {
      id: 'crops',
      title: 'Crop Recommendations',
      description: 'Get AI-powered suggestions for optimal crop selection based on your soil and climate conditions.',
      icon: Sprout,
      color: 'from-green-500 to-emerald-600',
      textColor: 'text-green-700',
      bgColor: 'bg-green-50',
    },
    {
      id: 'weather',
      title: 'Weather Advisory',
      description: 'Receive personalized farming advice based on current and forecasted weather patterns.',
      icon: Cloud,
      color: 'from-blue-500 to-indigo-600',
      textColor: 'text-blue-700',
      bgColor: 'bg-blue-50',
    },
    {
      id: 'pests',
      title: 'Pest & Disease Management',
      description: 'Identify threats and get treatment recommendations to protect your crops.',
      icon: Bug,
      color: 'from-red-500 to-pink-600',
      textColor: 'text-red-700',
      bgColor: 'bg-red-50',
    },
    {
      id: 'irrigation',
      title: 'Smart Irrigation',
      description: 'Optimize water usage with AI-driven irrigation scheduling and soil moisture analysis.',
      icon: Droplets,
      color: 'from-cyan-500 to-blue-600',
      textColor: 'text-cyan-700',
      bgColor: 'bg-cyan-50',
    },
    {
      id: 'market',
      title: 'Market Insights',
      description: 'Stay informed about crop prices, demand trends, and optimal selling opportunities.',
      icon: TrendingUp,
      color: 'from-purple-500 to-indigo-600',
      textColor: 'text-purple-700',
      bgColor: 'bg-purple-50',
    },
    {
      id: 'calendar',
      title: 'Farming Calendar',
      description: 'Plan your farming activities with seasonal recommendations and important dates.',
      icon: Calendar,
      color: 'from-orange-500 to-red-600',
      textColor: 'text-orange-700',
      bgColor: 'bg-orange-50',
    },
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-orange-500" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to AgriAI</h1>
        <p className="text-lg text-gray-600">Your intelligent farming companion for smarter agricultural decisions</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color} mt-1`}>{stat.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                <div className={`w-6 h-6 rounded ${stat.color.replace('text-', 'bg-')}`}></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Alerts */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Alerts & Notifications</h2>
        <div className="space-y-3">
          {recentAlerts.map((alert, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors duration-200">
              {getAlertIcon(alert.type)}
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {actionCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              onClick={() => onNavigate(card.id as ViewType)}
              className={`${card.bgColor} rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 cursor-pointer group`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${card.color} shadow-sm`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <ArrowRight className={`h-5 w-5 ${card.textColor} opacity-0 group-hover:opacity-100 transition-opacity duration-200`} />
              </div>
              <h3 className={`text-lg font-semibold ${card.textColor} mb-2`}>{card.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{card.description}</p>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-4 justify-center">
        <button
          onClick={() => onNavigate('assistant')}
          className="flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow-sm hover:shadow-md"
        >
          <MessageCircle className="h-5 w-5" />
          <span className="font-medium">Ask AI Assistant</span>
        </button>
        <button
          onClick={() => onNavigate('resources')}
          className="flex items-center space-x-2 bg-white text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200 shadow-sm hover:shadow-md border border-gray-200"
        >
          <Book className="h-5 w-5" />
          <span className="font-medium">Browse Resources</span>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;