import React, { useState } from 'react';
import { Droplets, Thermometer, Calendar, TrendingDown, TrendingUp, Activity, AlertCircle, AlertTriangle } from 'lucide-react';

const IrrigationAdvice: React.FC = () => {
  const [cropType, setCropType] = useState('wheat');
  const [growthStage, setGrowthStage] = useState('flowering');
  const [soilType, setSoilType] = useState('loamy');
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Generate dynamic soil moisture data based on crop, stage, and soil type
  const generateSoilMoistureData = () => {
    const cropWaterNeeds = {
      wheat: { base: 65, variation: 10 },
      rice: { base: 85, variation: 8 },
      corn: { base: 70, variation: 12 },
      cotton: { base: 60, variation: 15 },
      tomato: { base: 75, variation: 10 },
    };

    const stageMultipliers = {
      seedling: 0.8,
      vegetative: 1.0,
      flowering: 1.3,
      fruiting: 1.2,
      maturity: 0.7,
    };

    const soilRetention = {
      clay: 1.2,
      sandy: 0.7,
      loamy: 1.0,
      silty: 1.1,
    };

    const baseMoisture = cropWaterNeeds[cropType as keyof typeof cropWaterNeeds]?.base || 65;
    const stageMultiplier = stageMultipliers[growthStage as keyof typeof stageMultipliers] || 1.0;
    const soilMultiplier = soilRetention[soilType as keyof typeof soilRetention] || 1.0;

    const targetMoisture = Math.round(baseMoisture * stageMultiplier * soilMultiplier);

    return [
      {
        depth: '0-15cm',
        moisture: Math.max(30, Math.min(95, targetMoisture + Math.random() * 20 - 10)),
        optimal: Math.max(50, Math.min(90, targetMoisture + 5)),
        status: 'good'
      },
      {
        depth: '15-30cm',
        moisture: Math.max(25, Math.min(90, targetMoisture - 5 + Math.random() * 15 - 7)),
        optimal: Math.max(45, Math.min(85, targetMoisture)),
        status: 'good'
      },
      {
        depth: '30-45cm',
        moisture: Math.max(20, Math.min(85, targetMoisture - 10 + Math.random() * 20 - 10)),
        optimal: Math.max(40, Math.min(80, targetMoisture - 5)),
        status: 'good'
      },
      {
        depth: '45-60cm',
        moisture: Math.max(15, Math.min(80, targetMoisture - 15 + Math.random() * 25 - 12)),
        optimal: Math.max(35, Math.min(75, targetMoisture - 10)),
        status: 'good'
      },
    ].map(layer => ({
      ...layer,
      moisture: Math.round(layer.moisture),
      optimal: Math.round(layer.optimal),
      status: layer.moisture < layer.optimal * 0.7 ? 'critical' : 
              layer.moisture < layer.optimal * 0.85 ? 'low' : 'good'
    }));
  };

  const soilMoistureData = generateSoilMoistureData();

  // Generate dynamic irrigation schedule
  const generateIrrigationSchedule = () => {
    const cropSchedules = {
      wheat: {
        seedling: { frequency: 3, duration: 1.5, amount: 15 },
        vegetative: { frequency: 4, duration: 2, amount: 20 },
        flowering: { frequency: 2, duration: 2.5, amount: 30 },
        fruiting: { frequency: 3, duration: 2, amount: 25 },
        maturity: { frequency: 7, duration: 1, amount: 10 },
      },
      rice: {
        seedling: { frequency: 1, duration: 3, amount: 40 },
        vegetative: { frequency: 1, duration: 4, amount: 50 },
        flowering: { frequency: 1, duration: 4, amount: 55 },
        fruiting: { frequency: 2, duration: 3, amount: 45 },
        maturity: { frequency: 4, duration: 2, amount: 25 },
      },
      corn: {
        seedling: { frequency: 4, duration: 1.5, amount: 18 },
        vegetative: { frequency: 3, duration: 2, amount: 25 },
        flowering: { frequency: 2, duration: 3, amount: 35 },
        fruiting: { frequency: 2, duration: 2.5, amount: 30 },
        maturity: { frequency: 5, duration: 1.5, amount: 15 },
      },
      cotton: {
        seedling: { frequency: 5, duration: 1, amount: 12 },
        vegetative: { frequency: 4, duration: 1.5, amount: 18 },
        flowering: { frequency: 3, duration: 2, amount: 25 },
        fruiting: { frequency: 3, duration: 2.5, amount: 28 },
        maturity: { frequency: 7, duration: 1, amount: 10 },
      },
      tomato: {
        seedling: { frequency: 2, duration: 1, amount: 15 },
        vegetative: { frequency: 2, duration: 1.5, amount: 20 },
        flowering: { frequency: 2, duration: 2, amount: 25 },
        fruiting: { frequency: 1, duration: 2, amount: 30 },
        maturity: { frequency: 3, duration: 1.5, amount: 18 },
      },
    };

    const schedule = cropSchedules[cropType as keyof typeof cropSchedules]?.[growthStage as keyof typeof cropSchedules['wheat']] || 
                    { frequency: 3, duration: 2, amount: 20 };

    const days = ['Today', 'Tomorrow', 'Day 3', 'Day 4', 'Day 5'];
    const zones = ['Zone A', 'Zone B', 'Zone C', 'Zone A', 'Zone B'];
    
    return days.map((day, index) => {
      const shouldIrrigate = (index + 1) % schedule.frequency === 0 || index === 0;
      const isRestDay = !shouldIrrigate && Math.random() > 0.7;
      
      if (isRestDay) {
        return {
          date: day,
          time: 'Rest Day',
          duration: '-',
          amount: '-',
          status: 'rest',
          zone: 'All Zones'
        };
      }
      
      if (shouldIrrigate) {
        return {
          date: day,
          time: index === 0 ? '6:00 AM' : `${6 + Math.floor(Math.random() * 2)}:${Math.random() > 0.5 ? '00' : '30'} AM`,
          duration: `${schedule.duration + (Math.random() * 0.5 - 0.25)} hours`,
          amount: `${Math.round(schedule.amount + (Math.random() * 10 - 5))}mm`,
          status: index === 0 ? 'pending' : 'scheduled',
          zone: zones[index]
        };
      }
      
      return {
        date: day,
        time: 'Monitor Only',
        duration: '-',
        amount: '-',
        status: 'monitor',
        zone: zones[index]
      };
    });
  };

  const irrigationSchedule = generateIrrigationSchedule();

  // Generate dynamic recommendations
  const generateRecommendations = () => {
    const recommendations = [];
    
    // Check soil moisture levels
    const criticalLayers = soilMoistureData.filter(layer => layer.status === 'critical');
    const lowLayers = soilMoistureData.filter(layer => layer.status === 'low');
    
    if (criticalLayers.length > 0) {
      recommendations.push({
        title: 'Critical Moisture Alert',
        message: `${criticalLayers.map(l => l.depth).join(', ')} showing critical moisture levels. Immediate irrigation required.`,
        priority: 'high',
        icon: AlertTriangle,
      });
    }
    
    if (lowLayers.length > 0) {
      recommendations.push({
        title: 'Low Moisture Warning',
        message: `${lowLayers.map(l => l.depth).join(', ')} showing low moisture. Plan irrigation within 24 hours.`,
        priority: 'medium',
        icon: Droplets,
      });
    }
    
    // Growth stage specific advice
    const stageAdvice = {
      seedling: {
        title: 'Seedling Stage Care',
        message: 'Light, frequent irrigation needed. Avoid waterlogging which can cause damping-off disease.',
        priority: 'medium',
      },
      vegetative: {
        title: 'Vegetative Growth Support',
        message: 'Maintain consistent moisture for healthy leaf and stem development. Deep watering preferred.',
        priority: 'low',
      },
      flowering: {
        title: 'Critical Flowering Period',
        message: 'Most water-sensitive stage. Maintain optimal moisture to prevent flower drop and ensure good pollination.',
        priority: 'high',
      },
      fruiting: {
        title: 'Fruit Development Phase',
        message: 'Consistent moisture crucial for fruit size and quality. Avoid water stress during fruit filling.',
        priority: 'medium',
      },
      maturity: {
        title: 'Pre-Harvest Management',
        message: 'Reduce irrigation frequency to promote maturity and prevent quality issues.',
        priority: 'low',
      },
    };
    
    const currentStageAdvice = stageAdvice[growthStage as keyof typeof stageAdvice];
    if (currentStageAdvice) {
      recommendations.push({
        ...currentStageAdvice,
        icon: Calendar,
      });
    }
    
    // Soil type specific advice
    const soilAdvice = {
      clay: {
        title: 'Clay Soil Management',
        message: 'Clay soils retain water well but drain slowly. Water deeply but less frequently to prevent waterlogging.',
        priority: 'low',
      },
      sandy: {
        title: 'Sandy Soil Care',
        message: 'Sandy soils drain quickly. Increase irrigation frequency with smaller amounts to maintain moisture.',
        priority: 'medium',
      },
      loamy: {
        title: 'Optimal Soil Conditions',
        message: 'Loamy soil provides good drainage and retention. Follow standard irrigation practices.',
        priority: 'low',
      },
      silty: {
        title: 'Silty Soil Considerations',
        message: 'Silty soils can compact when wet. Ensure proper drainage and avoid irrigation during wet periods.',
        priority: 'low',
      },
    };
    
    const currentSoilAdvice = soilAdvice[soilType as keyof typeof soilAdvice];
    if (currentSoilAdvice) {
      recommendations.push({
        ...currentSoilAdvice,
        icon: Droplets,
      });
    }
    
    return recommendations.slice(0, 4); // Limit to 4 recommendations
  };

  const recommendations = generateRecommendations();

  // Generate dynamic water usage stats
  const generateWaterUsageStats = () => {
    const cropWaterUse = {
      wheat: { daily: 2000, efficiency: 85 },
      rice: { daily: 4500, efficiency: 75 },
      corn: { daily: 2800, efficiency: 88 },
      cotton: { daily: 2200, efficiency: 82 },
      tomato: { daily: 3200, efficiency: 90 },
    };
    
    const stageMultipliers = {
      seedling: 0.6,
      vegetative: 1.0,
      flowering: 1.4,
      fruiting: 1.2,
      maturity: 0.5,
    };
    
    const baseUsage = cropWaterUse[cropType as keyof typeof cropWaterUse]?.daily || 2500;
    const stageMultiplier = stageMultipliers[growthStage as keyof typeof stageMultipliers] || 1.0;
    const efficiency = cropWaterUse[cropType as keyof typeof cropWaterUse]?.efficiency || 85;
    
    const todayUsage = Math.round(baseUsage * stageMultiplier);
    
    return {
      today: todayUsage,
      week: todayUsage * 7,
      month: todayUsage * 30,
      efficiency: efficiency + Math.floor(Math.random() * 10 - 5),
    };
  };

  const waterUsageStats = generateWaterUsageStats();

  // Update data when inputs change
  React.useEffect(() => {
    setLastUpdated(new Date());
  }, [cropType, growthStage, soilType]);

  const getScheduleStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-orange-100 text-orange-700';
      case 'scheduled':
        return 'bg-blue-100 text-blue-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'rest':
        return 'bg-gray-100 text-gray-700';
      case 'monitor':
        return 'bg-purple-100 text-purple-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical':
        return 'text-red-600 bg-red-100';
      case 'low':
        return 'text-yellow-600 bg-yellow-100';
      case 'good':
        return 'text-green-600 bg-green-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      default:
        return 'border-l-green-500 bg-green-50';
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Smart Irrigation Management</h1>
        <p className="text-lg text-gray-600">Optimize water usage with AI-powered irrigation recommendations</p>
      </div>

      {/* Crop Information */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Crop Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Crop Type</label>
            <select
              value={cropType}
              onChange={(e) => setCropType(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="wheat">Wheat</option>
              <option value="rice">Rice</option>
              <option value="corn">Corn</option>
              <option value="cotton">Cotton</option>
              <option value="tomato">Tomato</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Growth Stage</label>
            <select
              value={growthStage}
              onChange={(e) => setGrowthStage(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="seedling">Seedling</option>
              <option value="vegetative">Vegetative</option>
              <option value="flowering">Flowering</option>
              <option value="fruiting">Fruiting</option>
              <option value="maturity">Maturity</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Soil Type</label>
            <select
              value={soilType}
              onChange={(e) => setSoilType(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="clay">Clay</option>
              <option value="sandy">Sandy</option>
              <option value="loamy">Loamy</option>
              <option value="silty">Silty</option>
            </select>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          <p>Last updated: {lastUpdated.toLocaleString()}</p>
          <p>Current settings: {cropType.charAt(0).toUpperCase() + cropType.slice(1)} • {growthStage.charAt(0).toUpperCase() + growthStage.slice(1)} stage • {soilType.charAt(0).toUpperCase() + soilType.slice(1)} soil</p>
        </div>
      </div>

      {/* Water Usage Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Usage</p>
              <p className="text-2xl font-bold text-blue-600">{waterUsageStats.today}L</p>
            </div>
            <Droplets className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">This Week</p>
              <p className="text-2xl font-bold text-indigo-600">{waterUsageStats.week}L</p>
            </div>
            <TrendingUp className="h-8 w-8 text-indigo-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">This Month</p>
              <p className="text-2xl font-bold text-purple-600">{waterUsageStats.month}L</p>
            </div>
            <Activity className="h-8 w-8 text-purple-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Efficiency</p>
              <p className="text-2xl font-bold text-green-600">{waterUsageStats.efficiency}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-green-500" />
          </div>
        </div>
      </div>

      {/* Soil Moisture Levels */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Thermometer className="h-5 w-5 text-blue-600 mr-2" />
          Soil Moisture Levels
        </h2>
        <div className="space-y-4">
          {soilMoistureData.map((layer, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{layer.depth}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(layer.status)}`}>
                    {layer.status.toUpperCase()}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      layer.status === 'good' ? 'bg-green-500' : 
                      layer.status === 'low' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${(layer.moisture / layer.optimal) * 100}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-sm text-gray-600 mt-1">
                  <span>Current: {layer.moisture}%</span>
                  <span>Optimal: {layer.optimal}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Irrigation Schedule */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <Calendar className="h-5 w-5 text-green-600 mr-2" />
          Irrigation Schedule
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Time</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Duration</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Water Amount</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Zone</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
              </tr>
            </thead>
            <tbody>
              {irrigationSchedule.map((schedule, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium">{schedule.date}</td>
                  <td className="py-3 px-4">{schedule.time}</td>
                  <td className="py-3 px-4">{schedule.duration}</td>
                  <td className="py-3 px-4">{schedule.amount}</td>
                  <td className="py-3 px-4">{schedule.zone}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getScheduleStatusColor(schedule.status)}`}>
                      {schedule.status.toUpperCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recommendations */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900">AI Recommendations</h2>
        {recommendations.map((rec, index) => {
          const Icon = rec.icon;
          return (
            <div key={index} className={`p-4 rounded-lg border-l-4 ${getPriorityColor(rec.priority)}`}>
              <div className="flex items-start space-x-3">
                <Icon className="h-5 w-5 mt-0.5 text-gray-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">{rec.title}</h3>
                  <p className="text-gray-700 text-sm mt-1">{rec.message}</p>
                  <span
                    className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                      rec.priority === 'high'
                        ? 'bg-red-100 text-red-700'
                        : rec.priority === 'medium'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-green-100 text-green-700'
                    }`}
                  >
                    {rec.priority.toUpperCase()} PRIORITY
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default IrrigationAdvice;