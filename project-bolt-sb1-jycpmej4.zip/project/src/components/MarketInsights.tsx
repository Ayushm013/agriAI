import React, { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Calendar, MapPin, AlertCircle, Target } from 'lucide-react';

const MarketInsights: React.FC = () => {
  const [selectedCrop, setSelectedCrop] = useState('wheat');
  const [timeRange, setTimeRange] = useState('30d');

  const priceData = {
    wheat: { current: 2250, change: 5.2, trend: 'up' },
    rice: { current: 3100, change: -2.1, trend: 'down' },
    corn: { current: 1950, change: 8.7, trend: 'up' },
    cotton: { current: 5600, change: -1.5, trend: 'down' },
    soybean: { current: 4200, change: 12.3, trend: 'up' },
  };

  const marketTrends = [
    {
      crop: 'Wheat',
      demand: 'High',
      supply: 'Medium',
      forecast: 'Bullish',
      confidence: 85,
      bestTime: 'Next 15 days',
      reason: 'Export demand increasing due to global shortage',
    },
    {
      crop: 'Rice',
      demand: 'Medium',
      supply: 'High',
      forecast: 'Bearish',
      confidence: 72,
      bestTime: 'Wait 3-4 weeks',
      reason: 'Bumper harvest expected to reduce prices',
    },
    {
      crop: 'Cotton',
      demand: 'High',
      supply: 'Low',
      forecast: 'Bullish',
      confidence: 91,
      bestTime: 'Immediate',
      reason: 'Textile industry recovery driving demand',
    },
  ];

  const marketAlerts = [
    {
      type: 'price',
      message: 'Wheat prices up 12% this week - Consider selling stored produce',
      urgency: 'high',
      action: 'Monitor daily for optimal selling point',
    },
    {
      type: 'demand',
      message: 'Export opportunities for organic rice opening up',
      urgency: 'medium',
      action: 'Contact export agents for better rates',
    },
    {
      type: 'seasonal',
      message: 'Post-harvest season approaching - Prices may drop',
      urgency: 'low',
      action: 'Plan storage strategy or immediate sales',
    },
  ];

  const regionalPrices = [
    { market: 'Delhi Mandi', price: 2280, distance: '250 km', transport: 180 },
    { market: 'Local Market', price: 2150, distance: '15 km', transport: 25 },
    { market: 'Jaipur APMC', price: 2320, distance: '180 km', transport: 140 },
    { market: 'Mumbai Port', price: 2450, distance: '420 km', transport: 350 },
  ];

  const crops = ['wheat', 'rice', 'corn', 'cotton', 'soybean'];

  const getTrendIcon = (trend: string) => {
    return trend === 'up' ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />;
  };

  const getTrendColor = (trend: string) => {
    return trend === 'up' ? 'text-green-600' : 'text-red-600';
  };

  const getForecastColor = (forecast: string) => {
    return forecast === 'Bullish' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      default:
        return 'border-l-blue-500 bg-blue-50';
    }
  };

  const getBestPrice = () => {
    return Math.max(...regionalPrices.map(p => p.price - p.transport));
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Market Insights & Price Intelligence</h1>
        <p className="text-lg text-gray-600">Make informed selling decisions with real-time market data</p>
      </div>

      {/* Price Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {Object.entries(priceData).map(([crop, data]) => (
          <div
            key={crop}
            className={`bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200 cursor-pointer ${
              selectedCrop === crop ? 'ring-2 ring-green-500 border-green-200' : ''
            }`}
            onClick={() => setSelectedCrop(crop)}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-gray-900 capitalize">{crop}</h3>
              <span className={`flex items-center space-x-1 ${getTrendColor(data.trend)}`}>
                {getTrendIcon(data.trend)}
                <span className="text-sm">{Math.abs(data.change)}%</span>
              </span>
            </div>
            <p className="text-lg font-bold text-gray-900">₹{data.current}</p>
            <p className="text-xs text-gray-500">per quintal</p>
          </div>
        ))}
      </div>

      {/* Market Alerts */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900 flex items-center">
          <AlertCircle className="h-5 w-5 text-orange-500 mr-2" />
          Market Alerts
        </h2>
        {marketAlerts.map((alert, index) => (
          <div key={index} className={`p-4 rounded-lg border-l-4 ${getUrgencyColor(alert.urgency)}`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="font-medium text-gray-900">{alert.message}</p>
                <p className="text-sm text-gray-600 mt-1">Recommended Action: {alert.action}</p>
              </div>
              <span
                className={`px-2 py-1 rounded text-xs font-medium ${
                  alert.urgency === 'high'
                    ? 'bg-red-100 text-red-700'
                    : alert.urgency === 'medium'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-blue-100 text-blue-700'
                }`}
              >
                {alert.urgency.toUpperCase()}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Market Trends Analysis */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <BarChart3 className="h-5 w-5 text-green-600 mr-2" />
          Market Trends & Forecasts
        </h2>
        <div className="space-y-6">
          {marketTrends.map((trend, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{trend.crop}</h3>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getForecastColor(trend.forecast)}`}>
                    {trend.forecast}
                  </span>
                  <span className="text-sm text-gray-600">Confidence: {trend.confidence}%</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">Demand</p>
                  <p className={`font-semibold ${
                    trend.demand === 'High' ? 'text-green-600' : 
                    trend.demand === 'Medium' ? 'text-yellow-600' : 'text-red-600'
                  }`}>{trend.demand}</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">Supply</p>
                  <p className={`font-semibold ${
                    trend.supply === 'High' ? 'text-red-600' : 
                    trend.supply === 'Medium' ? 'text-yellow-600' : 'text-green-600'
                  }`}>{trend.supply}</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600 flex items-center justify-center">
                    <Target className="h-4 w-4 mr-1" />
                    Best Time to Sell
                  </p>
                  <p className="font-semibold text-blue-600">{trend.bestTime}</p>
                </div>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-800"><strong>Analysis:</strong> {trend.reason}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Regional Price Comparison */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <MapPin className="h-5 w-5 text-purple-600 mr-2" />
          Regional Price Comparison
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Market</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Price/Quintal</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Distance</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Transport Cost</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Net Price</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Recommendation</th>
              </tr>
            </thead>
            <tbody>
              {regionalPrices.map((market, index) => {
                const netPrice = market.price - market.transport;
                const isBest = netPrice === getBestPrice();
                return (
                  <tr key={index} className={`border-b border-gray-100 hover:bg-gray-50 ${isBest ? 'bg-green-50' : ''}`}>
                    <td className="py-3 px-4 font-medium">{market.market}</td>
                    <td className="py-3 px-4">₹{market.price}</td>
                    <td className="py-3 px-4">{market.distance}</td>
                    <td className="py-3 px-4">₹{market.transport}</td>
                    <td className="py-3 px-4 font-semibold">₹{netPrice}</td>
                    <td className="py-3 px-4">
                      {isBest ? (
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">
                          BEST OPTION
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                          COMPARE
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-4 justify-center">
        <button className="flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow-sm">
          <DollarSign className="h-5 w-5" />
          <span>Get Selling Quote</span>
        </button>
        <button className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-sm">
          <Calendar className="h-5 w-5" />
          <span>Set Price Alerts</span>
        </button>
        <button className="flex items-center space-x-2 bg-white text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200 shadow-sm border border-gray-200">
          <BarChart3 className="h-5 w-5" />
          <span>View Detailed Analytics</span>
        </button>
      </div>
    </div>
  );
};

export default MarketInsights;