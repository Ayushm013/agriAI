import React, { useState } from 'react';
import { Sprout, MapPin, Thermometer, Droplets, Calendar, TrendingUp, AlertCircle } from 'lucide-react';

interface FormData {
  location: string;
  soilType: string;
  season: string;
  farmSize: string;
  irrigationType: string;
  previousCrop: string;
}

const CropRecommendation: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    location: '',
    soilType: '',
    season: '',
    farmSize: '',
    irrigationType: '',
    previousCrop: '',
  });

  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const soilTypes = ['Clay', 'Sandy', 'Loamy', 'Silty', 'Peaty', 'Chalky'];
  const seasons = ['Spring', 'Summer', 'Monsoon', 'Winter'];
  const irrigationTypes = ['Drip Irrigation', 'Sprinkler', 'Flood Irrigation', 'Rainfed'];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const generateRecommendations = () => {
    setLoading(true);
    // Generate dynamic recommendations based on user input
    setTimeout(() => {
      const dynamicRecommendations = generateDynamicRecommendations(formData);
      setRecommendations(dynamicRecommendations);
      setLoading(false);
    }, 2000);
  };

  const generateDynamicRecommendations = (data: FormData) => {
    const cropDatabase = {
      'Spring': {
        'Clay': [
          { crop: 'Rice', base: 85, yield: '50-60', period: '120-150', water: 'High', profit: 'High', demand: 'Excellent' },
          { crop: 'Cotton', base: 78, yield: '15-20', period: '180-200', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Sugarcane', base: 82, yield: '80-100', period: '300-365', water: 'Very High', profit: 'High', demand: 'Good' },
        ],
        'Sandy': [
          { crop: 'Millet', base: 88, yield: '8-12', period: '70-90', water: 'Low', profit: 'Medium', demand: 'Moderate' },
          { crop: 'Groundnut', base: 85, yield: '20-25', period: '100-120', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Watermelon', base: 80, yield: '25-35', period: '80-100', water: 'Medium', profit: 'High', demand: 'Excellent' },
        ],
        'Loamy': [
          { crop: 'Tomato', base: 92, yield: '40-60', period: '90-120', water: 'Medium', profit: 'Very High', demand: 'Excellent' },
          { crop: 'Maize', base: 89, yield: '35-45', period: '90-120', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Soybean', base: 86, yield: '15-20', period: '90-120', water: 'Medium', profit: 'High', demand: 'Good' },
        ],
      },
      'Summer': {
        'Clay': [
          { crop: 'Rice', base: 90, yield: '55-65', period: '120-150', water: 'High', profit: 'High', demand: 'Excellent' },
          { crop: 'Jute', base: 85, yield: '20-25', period: '120-150', water: 'High', profit: 'Medium', demand: 'Moderate' },
          { crop: 'Okra', base: 82, yield: '12-18', period: '60-90', water: 'Medium', profit: 'High', demand: 'Good' },
        ],
        'Sandy': [
          { crop: 'Sesame', base: 87, yield: '4-6', period: '90-120', water: 'Low', profit: 'High', demand: 'Good' },
          { crop: 'Cucumber', base: 84, yield: '15-25', period: '50-70', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Fodder Crops', base: 80, yield: '30-40', period: '60-90', water: 'Medium', profit: 'Medium', demand: 'Moderate' },
        ],
        'Loamy': [
          { crop: 'Cotton', base: 88, yield: '18-25', period: '180-200', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Sunflower', base: 85, yield: '12-18', period: '90-120', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Green Gram', base: 83, yield: '8-12', period: '60-90', water: 'Low', profit: 'Medium', demand: 'Good' },
        ],
      },
      'Monsoon': {
        'Clay': [
          { crop: 'Rice', base: 95, yield: '60-70', period: '120-150', water: 'High', profit: 'High', demand: 'Excellent' },
          { crop: 'Sugarcane', base: 88, yield: '90-110', period: '300-365', water: 'High', profit: 'High', demand: 'Good' },
          { crop: 'Banana', base: 85, yield: '40-60', period: '300-400', water: 'High', profit: 'Very High', demand: 'Excellent' },
        ],
        'Sandy': [
          { crop: 'Castor', base: 82, yield: '8-12', period: '150-180', water: 'Low', profit: 'Medium', demand: 'Moderate' },
          { crop: 'Black Gram', base: 80, yield: '6-10', period: '60-90', water: 'Low', profit: 'Medium', demand: 'Good' },
          { crop: 'Cowpea', base: 78, yield: '8-12', period: '60-90', water: 'Low', profit: 'Medium', demand: 'Moderate' },
        ],
        'Loamy': [
          { crop: 'Maize', base: 92, yield: '40-50', period: '90-120', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Sorghum', base: 89, yield: '25-35', period: '100-130', water: 'Medium', profit: 'Medium', demand: 'Moderate' },
          { crop: 'Pigeon Pea', base: 86, yield: '12-18', period: '150-180', water: 'Medium', profit: 'High', demand: 'Good' },
        ],
      },
      'Winter': {
        'Clay': [
          { crop: 'Wheat', base: 90, yield: '40-50', period: '120-150', water: 'Medium', profit: 'High', demand: 'Excellent' },
          { crop: 'Barley', base: 85, yield: '30-40', period: '110-140', water: 'Low', profit: 'Medium', demand: 'Moderate' },
          { crop: 'Mustard', base: 82, yield: '12-18', period: '90-120', water: 'Low', profit: 'High', demand: 'Good' },
        ],
        'Sandy': [
          { crop: 'Gram', base: 88, yield: '15-20', period: '95-120', water: 'Low', profit: 'High', demand: 'Good' },
          { crop: 'Lentil', base: 85, yield: '8-12', period: '100-130', water: 'Low', profit: 'High', demand: 'Good' },
          { crop: 'Coriander', base: 83, yield: '8-12', period: '90-120', water: 'Low', profit: 'High', demand: 'Good' },
        ],
        'Loamy': [
          { crop: 'Wheat', base: 95, yield: '45-55', period: '120-150', water: 'Medium', profit: 'High', demand: 'Excellent' },
          { crop: 'Pea', base: 88, yield: '12-18', period: '90-120', water: 'Medium', profit: 'High', demand: 'Good' },
          { crop: 'Potato', base: 92, yield: '200-300', period: '90-120', water: 'Medium', profit: 'Very High', demand: 'Excellent' },
        ],
      },
    };

    // Get base crops for the season and soil type
    const seasonCrops = cropDatabase[data.season as keyof typeof cropDatabase] || cropDatabase['Winter'];
    const soilCrops = seasonCrops[data.soilType as keyof typeof seasonCrops] || seasonCrops['Loamy'];

    // Apply modifiers based on other factors
    const modifiedCrops = soilCrops.map(crop => {
      let suitability = crop.base;
      let tips = [];
      let risks = [];

      // Irrigation type modifiers
      if (data.irrigationType === 'Drip Irrigation') {
        suitability += 5;
        tips.push('Drip irrigation will optimize water usage and reduce disease risk');
      } else if (data.irrigationType === 'Rainfed' && crop.water === 'High') {
        suitability -= 10;
        risks.push('High water requirement crop may struggle without irrigation');
      }

      // Farm size considerations
      const farmSizeNum = parseFloat(data.farmSize);
      if (farmSizeNum > 10 && crop.crop === 'Rice') {
        suitability += 3;
        tips.push('Large farm size suitable for mechanized rice cultivation');
      } else if (farmSizeNum < 2 && ['Cotton', 'Sugarcane'].includes(crop.crop)) {
        suitability -= 5;
        risks.push('Small farm size may not be economical for this crop');
      }

      // Previous crop rotation benefits
      if (data.previousCrop && data.previousCrop.toLowerCase().includes('legume') && 
          ['Wheat', 'Rice', 'Maize'].includes(crop.crop)) {
        suitability += 8;
        tips.push('Previous legume crop will provide nitrogen benefit');
      }

      // Location-based adjustments (simplified)
      if (data.location.toLowerCase().includes('punjab') && crop.crop === 'Wheat') {
        suitability += 5;
        tips.push('Punjab climate is ideal for wheat cultivation');
      } else if (data.location.toLowerCase().includes('kerala') && crop.crop === 'Rice') {
        suitability += 7;
        tips.push('Kerala\'s climate and soil perfect for rice farming');
      }

      // Ensure suitability stays within bounds
      suitability = Math.min(Math.max(suitability, 40), 98);

      // Generate specific tips and risks based on crop
      const cropSpecificData = getCropSpecificData(crop.crop, data);
      tips = [...tips, ...cropSpecificData.tips];
      risks = [...risks, ...cropSpecificData.risks];

      return {
        crop: crop.crop,
        suitability: Math.round(suitability),
        expectedYield: `${crop.yield} quintals/hectare`,
        growthPeriod: `${crop.period} days`,
        waterRequirement: crop.water,
        profitability: crop.profit,
        marketDemand: crop.demand,
        tips: tips.slice(0, 4), // Limit to 4 tips
        risks: risks.slice(0, 3), // Limit to 3 risks
      };
    });

    // Sort by suitability and return top 3
    return modifiedCrops.sort((a, b) => b.suitability - a.suitability).slice(0, 3);
  };

  const getCropSpecificData = (crop: string, data: FormData) => {
    const cropData: { [key: string]: { tips: string[], risks: string[] } } = {
      'Wheat': {
        tips: ['Plant in November for optimal growth', 'Use certified seeds for better yield', 'Apply nitrogen in 2-3 splits'],
        risks: ['Yellow rust in humid conditions', 'Aphid infestation during grain filling', 'Lodging in windy areas']
      },
      'Rice': {
        tips: ['Maintain 2-5cm water level during growth', 'Transplant 21-day old seedlings', 'Apply organic matter before planting'],
        risks: ['Blast disease in cool weather', 'Brown plant hopper during monsoon', 'Iron deficiency in alkaline soils']
      },
      'Cotton': {
        tips: ['Plant after soil temperature reaches 18°C', 'Maintain plant spacing of 45x15 cm', 'Regular monitoring for bollworm'],
        risks: ['Bollworm infestation during flowering', 'Whitefly causing leaf curl virus', 'Waterlogging damage to roots']
      },
      'Maize': {
        tips: ['Plant when soil moisture is adequate', 'Apply balanced NPK fertilizer', 'Earthing up at knee-high stage'],
        risks: ['Fall armyworm damage to leaves', 'Stem borer during vegetative stage', 'Cob rot in high humidity']
      },
      'Tomato': {
        tips: ['Use disease-resistant varieties', 'Provide support stakes for plants', 'Mulching to conserve moisture'],
        risks: ['Late blight in cool humid weather', 'Fruit borer damage to fruits', 'Bacterial wilt in heavy soils']
      },
      'Potato': {
        tips: ['Plant certified seed potatoes', 'Hill up soil around plants', 'Harvest when foliage turns yellow'],
        risks: ['Late blight fungal disease', 'Potato tuber moth damage', 'Greening of tubers in sunlight']
      },
      'Soybean': {
        tips: ['Inoculate seeds with rhizobium', 'Ensure good drainage', 'Harvest when pods rattle'],
        risks: ['Yellow mosaic virus', 'Pod borer during pod formation', 'Root rot in waterlogged conditions']
      },
      'Sugarcane': {
        tips: ['Plant healthy setts with 2-3 buds', 'Apply organic manure liberally', 'Maintain adequate moisture'],
        risks: ['Red rot disease', 'Early shoot borer damage', 'Waterlogging affecting root development']
      }
    };

    return cropData[crop] || {
      tips: ['Follow recommended package of practices', 'Monitor crop regularly for pests', 'Maintain proper plant nutrition'],
      risks: ['Pest and disease pressure', 'Weather-related stress', 'Market price fluctuations']
    };
  };

  const getSuitabilityColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 75) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Crop Recommendations</h1>
        <p className="text-lg text-gray-600">Get personalized crop suggestions based on your specific conditions</p>
      </div>

      {/* Input Form */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
          <MapPin className="h-5 w-5 text-green-600 mr-2" />
          Farm Details
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleInputChange}
              placeholder="Enter your location"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Soil Type</label>
            <select
              name="soilType"
              value={formData.soilType}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            >
              <option value="">Select soil type</option>
              {soilTypes.map((soil) => (
                <option key={soil} value={soil}>{soil}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Season</label>
            <select
              name="season"
              value={formData.season}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            >
              <option value="">Select season</option>
              {seasons.map((season) => (
                <option key={season} value={season}>{season}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Farm Size (hectares)</label>
            <input
              type="text"
              name="farmSize"
              value={formData.farmSize}
              onChange={handleInputChange}
              placeholder="Enter farm size"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Irrigation Type</label>
            <select
              name="irrigationType"
              value={formData.irrigationType}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            >
              <option value="">Select irrigation</option>
              {irrigationTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Previous Crop</label>
            <input
              type="text"
              name="previousCrop"
              value={formData.previousCrop}
              onChange={handleInputChange}
              placeholder="Last grown crop"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            />
          </div>
        </div>
        <button
          onClick={generateRecommendations}
          disabled={loading}
          className="mt-6 bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Analyzing...
            </>
          ) : (
            <>
              <Sprout className="h-4 w-4 mr-2" />
              Get Recommendations
            </>
          )}
        </button>
      </div>

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">Recommended Crops</h2>
          {recommendations.map((rec, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-gray-900">{rec.crop}</h3>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSuitabilityColor(rec.suitability)}`}>
                  {rec.suitability}% Suitable
                </span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-xs text-gray-500">Expected Yield</p>
                    <p className="text-sm font-medium">{rec.expectedYield}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Growth Period</p>
                    <p className="text-sm font-medium">{rec.growthPeriod}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Droplets className="h-4 w-4 text-cyan-600" />
                  <div>
                    <p className="text-xs text-gray-500">Water Need</p>
                    <p className="text-sm font-medium">{rec.waterRequirement}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Thermometer className="h-4 w-4 text-orange-600" />
                  <div>
                    <p className="text-xs text-gray-500">Market Demand</p>
                    <p className="text-sm font-medium">{rec.marketDemand}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">💡 Growing Tips</h4>
                  <ul className="space-y-1">
                    {rec.tips.map((tip: string, tipIndex: number) => (
                      <li key={tipIndex} className="text-sm text-gray-600 flex items-start">
                        <span className="w-1 h-1 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                    <AlertCircle className="h-4 w-4 text-orange-500 mr-1" />
                    Potential Risks
                  </h4>
                  <ul className="space-y-1">
                    {rec.risks.map((risk: string, riskIndex: number) => (
                      <li key={riskIndex} className="text-sm text-gray-600 flex items-start">
                        <span className="w-1 h-1 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {risk}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CropRecommendation;