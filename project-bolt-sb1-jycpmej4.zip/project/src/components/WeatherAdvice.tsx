import React, { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Wind, Thermometer, Droplets, Eye, AlertTriangle, MapPin } from 'lucide-react';

const WeatherAdvice: React.FC = () => {
  const [location, setLocation] = useState('');
  const [weatherData, setWeatherData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Generate dynamic weather data based on location
  const generateWeatherData = (locationInput: string) => {
    const locationLower = locationInput.toLowerCase();
    
    // Base weather patterns for different regions
    const regionWeatherPatterns = {
      // Northern India
      punjab: { temp: [25, 30], humidity: [45, 65], rain: [10, 40], wind: [8, 15] },
      haryana: { temp: [24, 29], humidity: [40, 60], rain: [15, 45], wind: [10, 18] },
      delhi: { temp: [26, 32], humidity: [50, 70], rain: [20, 50], wind: [6, 12] },
      
      // Western India
      maharashtra: { temp: [28, 35], humidity: [60, 80], rain: [30, 70], wind: [12, 20] },
      gujarat: { temp: [30, 38], humidity: [45, 65], rain: [5, 35], wind: [15, 25] },
      rajasthan: { temp: [32, 40], humidity: [25, 45], rain: [5, 25], wind: [18, 30] },
      
      // Southern India
      karnataka: { temp: [26, 32], humidity: [65, 85], rain: [40, 80], wind: [8, 16] },
      kerala: { temp: [28, 34], humidity: [75, 90], rain: [60, 95], wind: [10, 18] },
      'tamil nadu': { temp: [29, 36], humidity: [70, 85], rain: [35, 75], wind: [12, 22] },
      
      // Eastern India
      'west bengal': { temp: [27, 33], humidity: [70, 90], rain: [50, 85], wind: [8, 15] },
      odisha: { temp: [28, 35], humidity: [65, 85], rain: [45, 80], wind: [10, 18] },
      bihar: { temp: [26, 32], humidity: [60, 80], rain: [40, 75], wind: [6, 14] },
      
      // Central India
      'madhya pradesh': { temp: [27, 34], humidity: [50, 70], rain: [25, 60], wind: [10, 18] },
      chhattisgarh: { temp: [28, 35], humidity: [60, 80], rain: [35, 70], wind: [8, 16] },
    };

    // Find matching region
    let selectedPattern = regionWeatherPatterns.punjab; // default
    for (const [region, pattern] of Object.entries(regionWeatherPatterns)) {
      if (locationLower.includes(region)) {
        selectedPattern = pattern;
        break;
      }
    }

    // Generate current weather
    const currentTemp = Math.round(selectedPattern.temp[0] + Math.random() * (selectedPattern.temp[1] - selectedPattern.temp[0]));
    const currentHumidity = Math.round(selectedPattern.humidity[0] + Math.random() * (selectedPattern.humidity[1] - selectedPattern.humidity[0]));
    const currentWind = Math.round(selectedPattern.wind[0] + Math.random() * (selectedPattern.wind[1] - selectedPattern.wind[0]));
    const visibility = Math.round(6 + Math.random() * 4);

    // Generate 5-day forecast
    const forecast = [];
    const days = ['Today', 'Tomorrow', 'Wednesday', 'Thursday', 'Friday'];
    const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Light Rain', 'Heavy Rain'];
    const icons = ['sunny', 'partly-cloudy', 'cloudy', 'rainy', 'heavy-rain'];

    for (let i = 0; i < 5; i++) {
      const tempVariation = Math.round(-3 + Math.random() * 6);
      const temp = Math.max(20, Math.min(45, currentTemp + tempVariation));
      const rainChance = Math.round(selectedPattern.rain[0] + Math.random() * (selectedPattern.rain[1] - selectedPattern.rain[0]));
      
      let conditionIndex;
      if (rainChance > 80) conditionIndex = 4; // Heavy Rain
      else if (rainChance > 50) conditionIndex = 3; // Light Rain
      else if (rainChance > 30) conditionIndex = 2; // Cloudy
      else if (rainChance > 15) conditionIndex = 1; // Partly Cloudy
      else conditionIndex = 0; // Sunny

      forecast.push({
        day: days[i],
        temp: `${temp}°C`,
        condition: conditions[conditionIndex],
        rain: rainChance,
        icon: icons[conditionIndex]
      });
    }

    return {
      current: {
        temperature: currentTemp,
        humidity: currentHumidity,
        windSpeed: currentWind,
        visibility: visibility,
        condition: forecast[0].condition,
        uvIndex: Math.round(3 + Math.random() * 5),
      },
      forecast: forecast
    };
  };

  // Generate farming advice based on weather and location
  const generateFarmingAdvice = (weather: any, locationInput: string) => {
    const advice = [];
    const locationLower = locationInput.toLowerCase();

    // Temperature-based advice
    if (weather.current.temperature > 35) {
      advice.push({
        title: 'Heat Stress Management',
        advice: 'High temperatures detected. Increase irrigation frequency and provide shade for sensitive crops. Avoid field operations during peak heat hours (11 AM - 4 PM).',
        priority: 'high'
      });
    } else if (weather.current.temperature < 15) {
      advice.push({
        title: 'Cold Protection',
        advice: 'Low temperatures may affect crop growth. Consider covering sensitive plants and delay irrigation until temperatures rise.',
        priority: 'medium'
      });
    }

    // Humidity-based advice
    if (weather.current.humidity > 80) {
      advice.push({
        title: 'Disease Prevention',
        advice: 'High humidity increases fungal disease risk. Apply preventive fungicide sprays and ensure good air circulation around plants.',
        priority: 'high'
      });
    } else if (weather.current.humidity < 40) {
      advice.push({
        title: 'Moisture Conservation',
        advice: 'Low humidity may cause water stress. Increase irrigation frequency and consider mulching to retain soil moisture.',
        priority: 'medium'
      });
    }

    // Rain-based advice from forecast
    const heavyRainDays = weather.forecast.filter((day: any) => day.rain > 70).length;
    const dryDays = weather.forecast.filter((day: any) => day.rain < 20).length;

    if (heavyRainDays >= 2) {
      advice.push({
        title: 'Waterlogging Prevention',
        advice: 'Heavy rainfall expected. Ensure proper field drainage, avoid heavy machinery use, and postpone fertilizer application.',
        priority: 'high'
      });
    } else if (dryDays >= 3) {
      advice.push({
        title: 'Irrigation Planning',
        advice: 'Dry weather ahead. Plan irrigation schedule accordingly and check soil moisture levels regularly.',
        priority: 'medium'
      });
    }

    // Wind-based advice
    if (weather.current.windSpeed > 20) {
      advice.push({
        title: 'Wind Damage Prevention',
        advice: 'Strong winds may cause lodging in tall crops. Provide support stakes for vulnerable plants and avoid spraying operations.',
        priority: 'medium'
      });
    }

    // Location-specific advice
    if (locationLower.includes('punjab') || locationLower.includes('haryana')) {
      advice.push({
        title: 'Wheat Belt Advisory',
        advice: 'Monitor for yellow rust in wheat crops. Current weather conditions are favorable for wheat growth but watch for pest buildup.',
        priority: 'low'
      });
    } else if (locationLower.includes('kerala') || locationLower.includes('karnataka')) {
      advice.push({
        title: 'Tropical Climate Advisory',
        advice: 'High humidity is normal for your region. Focus on proper drainage and ventilation for crops. Spice crops should be monitored for fungal issues.',
        priority: 'low'
      });
    } else if (locationLower.includes('rajasthan') || locationLower.includes('gujarat')) {
      advice.push({
        title: 'Arid Region Advisory',
        advice: 'Water conservation is crucial. Use drip irrigation where possible and select drought-tolerant crop varieties.',
        priority: 'medium'
      });
    }

    return advice.slice(0, 4); // Return top 4 most relevant advice
  };

  // Generate weather alerts
  const generateWeatherAlerts = (weather: any, locationInput: string) => {
    const alerts = [];

    // Temperature alerts
    if (weather.current.temperature > 40) {
      alerts.push({
        type: 'warning',
        message: 'Extreme heat warning - temperatures above 40°C. Risk of heat stress in crops and livestock.',
        action: 'Increase irrigation frequency and provide shade. Avoid field work during peak hours.'
      });
    }

    // Humidity alerts
    if (weather.current.humidity > 85) {
      alerts.push({
        type: 'warning',
        message: 'Very high humidity levels detected. Increased risk of fungal diseases.',
        action: 'Apply preventive fungicide treatments and improve field ventilation.'
      });
    }

    // Rain alerts from forecast
    const tomorrowRain = weather.forecast[1]?.rain || 0;
    if (tomorrowRain > 80) {
      alerts.push({
        type: 'warning',
        message: 'Heavy rainfall expected tomorrow. Risk of waterlogging and field access issues.',
        action: 'Complete urgent field operations today and ensure drainage systems are clear.'
      });
    }

    // Wind alerts
    if (weather.current.windSpeed > 25) {
      alerts.push({
        type: 'info',
        message: 'Strong winds detected. Risk of crop lodging and spray drift.',
        action: 'Postpone spraying operations and provide support to tall crops.'
      });
    }

    // Default info if no major alerts
    if (alerts.length === 0) {
      alerts.push({
        type: 'info',
        message: 'Weather conditions are generally favorable for farming activities.',
        action: 'Continue with planned agricultural operations while monitoring conditions.'
      });
    }

    return alerts.slice(0, 3); // Return top 3 alerts
  };

  const handleLocationUpdate = () => {
    if (!location.trim()) {
      alert('Please enter a location');
      return;
    }

    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const newWeatherData = generateWeatherData(location);
      setWeatherData(newWeatherData);
      setLoading(false);
    }, 1500);
  };

  // Initialize with default location
  useEffect(() => {
    if (!weatherData) {
      const defaultWeather = generateWeatherData('Punjab, India');
      setWeatherData(defaultWeather);
      setLocation('Punjab, India');
    }
  }, []);

  if (!weatherData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  const farmingAdvice = generateFarmingAdvice(weatherData, location);
  const weatherAlerts = generateWeatherAlerts(weatherData, location);

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny':
        return <Sun className="h-8 w-8 text-yellow-500" />;
      case 'partly-cloudy':
        return <Cloud className="h-8 w-8 text-gray-500" />;
      case 'rainy':
      case 'heavy-rain':
        return <CloudRain className="h-8 w-8 text-blue-500" />;
      default:
        return <Cloud className="h-8 w-8 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      default:
        return 'border-l-green-500 bg-green-50';
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Weather-Based Farming Advice</h1>
        <p className="text-lg text-gray-600">Make informed decisions with localized weather insights</p>
      </div>

      {/* Location Input */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="flex items-center space-x-2 flex-1">
            <MapPin className="h-5 w-5 text-gray-400" />
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter your location (e.g., Punjab, Maharashtra, Kerala)"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
            />
          </div>
          <button 
            onClick={handleLocationUpdate}
            disabled={loading}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Loading...
              </>
            ) : (
              'Update Weather'
            )}
          </button>
        </div>
        {location && (
          <p className="text-sm text-gray-600 mt-2">
            Showing weather data for: <span className="font-medium">{location}</span>
          </p>
        )}
      </div>

      {/* Current Weather */}
      <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <h2 className="text-xl font-semibold mb-4">Current Weather - {location}</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <Thermometer className="h-6 w-6 mx-auto mb-2" />
            <p className="text-2xl font-bold">{weatherData.current.temperature}°C</p>
            <p className="text-sm opacity-90">Temperature</p>
          </div>
          <div className="text-center">
            <Droplets className="h-6 w-6 mx-auto mb-2" />
            <p className="text-2xl font-bold">{weatherData.current.humidity}%</p>
            <p className="text-sm opacity-90">Humidity</p>
          </div>
          <div className="text-center">
            <Wind className="h-6 w-6 mx-auto mb-2" />
            <p className="text-2xl font-bold">{weatherData.current.windSpeed} km/h</p>
            <p className="text-sm opacity-90">Wind Speed</p>
          </div>
          <div className="text-center">
            <Eye className="h-6 w-6 mx-auto mb-2" />
            <p className="text-2xl font-bold">{weatherData.current.visibility} km</p>
            <p className="text-sm opacity-90">Visibility</p>
          </div>
        </div>
        <div className="mt-4 text-center">
          <p className="text-lg opacity-90">Condition: {weatherData.current.condition}</p>
          <p className="text-sm opacity-75">UV Index: {weatherData.current.uvIndex}</p>
        </div>
      </div>

      {/* Weather Alerts */}
      {weatherAlerts.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-900">Weather Alerts</h2>
          {weatherAlerts.map((alert, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border-l-4 ${
                alert.type === 'warning'
                  ? 'bg-red-50 border-l-red-500'
                  : 'bg-blue-50 border-l-blue-500'
              }`}
            >
              <div className="flex items-start space-x-3">
                <AlertTriangle
                  className={`h-5 w-5 mt-0.5 ${
                    alert.type === 'warning' ? 'text-red-500' : 'text-blue-500'
                  }`}
                />
                <div>
                  <p className="font-medium text-gray-900">{alert.message}</p>
                  <p className="text-sm text-gray-600 mt-1">Recommended Action: {alert.action}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 5-Day Forecast */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">5-Day Forecast</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {weatherData.forecast.map((day: any, index: number) => (
            <div key={index} className="text-center p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors duration-200">
              <p className="font-medium text-gray-900 mb-2">{day.day}</p>
              <div className="flex justify-center mb-2">
                {getWeatherIcon(day.icon)}
              </div>
              <p className="text-lg font-semibold text-gray-800">{day.temp}</p>
              <p className="text-sm text-gray-600">{day.condition}</p>
              <div className="mt-2 flex items-center justify-center space-x-1 text-blue-600">
                <CloudRain className="h-4 w-4" />
                <span className="text-sm">{day.rain}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Farming Advice */}
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-gray-900">Weather-Based Farming Recommendations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {farmingAdvice.map((advice, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border-l-4 ${getPriorityColor(advice.priority)}`}
            >
              <h3 className="font-semibold text-gray-900 mb-2">{advice.title}</h3>
              <p className="text-gray-700 text-sm">{advice.advice}</p>
              <span
                className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                  advice.priority === 'high'
                    ? 'bg-red-100 text-red-700'
                    : advice.priority === 'medium'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-green-100 text-green-700'
                }`}
              >
                {advice.priority.toUpperCase()} PRIORITY
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WeatherAdvice;