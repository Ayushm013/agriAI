import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Bot, User, Lightbulb, Leaf, Droplets, Bug } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m your AI farming assistant. I can help you with crop recommendations, pest control, irrigation advice, market insights, and answer any farming-related questions. How can I assist you today?',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    "What's the best time to plant tomatoes?",
    "How do I control aphids on my crops?",
    "When should I water my wheat field?",
    "What are current market prices for rice?",
    "How to improve soil fertility naturally?",
    "Signs of nutrient deficiency in plants?",
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (messageContent?: string) => {
    const content = messageContent || inputValue.trim();
    if (!content) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(content);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: aiResponse,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (question: string): string => {
    const q = question.toLowerCase();

    if (q.includes('tomato') && q.includes('plant')) {
      return 'For tomatoes, the best planting time depends on your location:\n\n🌱 **Warm climates**: Plant in early spring after last frost\n🌱 **Cool climates**: Start indoors 6-8 weeks before last frost\n🌱 **Tropical areas**: Plant during cooler months\n\nKey tips:\n- Soil temperature should be 60-70°F (15-21°C)\n- Choose sunny location with 6-8 hours of direct sunlight\n- Ensure good drainage and add compost to soil\n- Space plants 24-36 inches apart\n\nWould you like specific advice for your region or growing conditions?';
    }

    if (q.includes('aphid') || (q.includes('pest') && q.includes('control'))) {
      return '🐛 **Aphid Control Strategy**:\n\n**Immediate Solutions:**\n- Spray with insecticidal soap solution (1 tbsp soap per quart water)\n- Use neem oil spray in early morning or evening\n- Blast off with strong water spray\n\n**Biological Control:**\n- Release ladybugs, lacewings, or parasitic wasps\n- Plant companion crops like marigolds, catnip, garlic\n\n**Prevention:**\n- Regular monitoring and early detection\n- Remove weeds that harbor aphids\n- Avoid over-fertilizing with nitrogen\n- Use reflective mulches\n\n**Severe Infestations:**\n- Apply systemic insecticides as last resort\n- Consider beneficial nematodes for soil-dwelling species\n\nMonitor weekly and act quickly when first spotted!';
    }

    if (q.includes('water') || q.includes('irrigat')) {
      return '💧 **Smart Irrigation Guidelines**:\n\n**Wheat Watering Schedule:**\n- **Seedling stage**: Light, frequent watering\n- **Tillering**: Deep watering every 7-10 days\n- **Flowering**: Critical period - maintain consistent moisture\n- **Grain filling**: Reduce frequency, deep watering\n\n**Best Practices:**\n- Water early morning (6-10 AM) to reduce evaporation\n- Check soil moisture 6 inches deep\n- Use drip or sprinkler irrigation for efficiency\n- Avoid watering during windy or hot midday periods\n\n**Signs to Watch:**\n✅ Soil feels moist but not waterlogged\n❌ Wilting during early morning hours\n❌ Soil cracks or becomes hydrophobic\n\nAdjust based on weather, soil type, and growth stage!';
    }

    if (q.includes('market') || q.includes('price')) {
      return '📈 **Current Market Intelligence**:\n\n**Rice Prices (per quintal):**\n- Local markets: ₹2,100-2,300\n- APMC rates: ₹2,250-2,400\n- Export quality: ₹2,500-2,700\n\n**Market Trends:**\n📊 Demand: Moderate to High\n📊 Supply: Adequate\n📊 Forecast: Stable with slight upward trend\n\n**Selling Tips:**\n- Quality premium for well-dried grain\n- Consider storage if prices expected to rise\n- Check transport costs to different markets\n- Grade your produce for better rates\n\n**Next 2 weeks**: Favorable selling window due to festival demand\n\nWould you like specific market information for your region or crop?';
    }

    if (q.includes('soil') && q.includes('fertility')) {
      return '🌱 **Natural Soil Fertility Enhancement**:\n\n**Organic Matter:**\n- Add compost, aged manure, or vermicompost\n- Green manure crops (legumes, mustard)\n- Crop residue incorporation\n\n**Biological Methods:**\n- Mycorrhizal fungi inoculation\n- Beneficial bacteria (Rhizobium, Azotobacter)\n- Vermiculture and earthworm activity\n\n**Cover Crops:**\n- Legumes for nitrogen fixation\n- Grasses for soil structure\n- Mixed covers for diverse benefits\n\n**Natural Amendments:**\n- Rock phosphate for phosphorus\n- Kelp meal for trace minerals\n- Bone meal for calcium and phosphorus\n\n**Soil Testing**: Get soil tested every 2-3 years to track improvements and adjust strategies.\n\nStart with one method and gradually build your soil health program!';
    }

    if (q.includes('nutrient') && q.includes('deficiency')) {
      return '🍃 **Nutrient Deficiency Identification**:\n\n**Nitrogen (N) Deficiency:**\n- Yellowing of older leaves first\n- Stunted growth, pale green color\n- **Solution**: Apply compost, urea, or organic nitrogen\n\n**Phosphorus (P) Deficiency:**\n- Purple or dark green leaves\n- Poor root development, delayed maturity\n- **Solution**: Bone meal, rock phosphate\n\n**Potassium (K) Deficiency:**\n- Brown leaf edges, weak stems\n- Poor fruit/grain quality\n- **Solution**: Wood ash, potash fertilizer\n\n**Iron Deficiency:**\n- Yellow leaves with green veins (chlorosis)\n- Common in alkaline soils\n- **Solution**: Iron sulfate, acidify soil\n\n**Quick Test**: Compare affected plants with healthy ones nearby. Soil testing provides definitive diagnosis.\n\nAddress deficiencies gradually to avoid shocking plants!';
    }

    // Default response
    return 'Thank you for your question! Based on your query, I\'d recommend:\n\n1. **Assessment**: Evaluate your specific growing conditions\n2. **Research**: Consider local climate and soil factors\n3. **Best Practices**: Follow proven agricultural methods\n4. **Monitoring**: Keep track of results and adjust accordingly\n\nFor more specific advice, could you provide more details about:\n- Your location and climate\n- Crop type and growth stage\n- Current growing conditions\n- Specific challenges you\'re facing\n\nI\'m here to help with detailed, actionable farming guidance!';
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Farming Assistant</h1>
        <p className="text-lg text-gray-600">Get instant answers to all your agricultural questions</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 h-[600px] flex flex-col">
        {/* Chat Header */}
        <div className="p-4 border-b border-gray-100 flex items-center space-x-3">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
            <Bot className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">AgriAI Assistant</h3>
            <p className="text-sm text-green-600">Online • Ready to help</p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.type === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {message.type === 'ai' && (
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="h-4 w-4 text-green-600" />
                </div>
              )}
              <div
                className={`max-w-[70%] p-3 rounded-lg ${
                  message.type === 'user'
                    ? 'bg-green-600 text-white ml-auto'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {message.content}
                </div>
                <p className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              {message.type === 'user' && (
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="h-4 w-4 text-blue-600" />
                </div>
              )}
            </div>
          ))}
          
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="h-4 w-4 text-green-600" />
              </div>
              <div className="bg-gray-100 text-gray-900 p-3 rounded-lg">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="px-4 py-2 border-t border-gray-100">
            <p className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <Lightbulb className="h-4 w-4 mr-1" />
              Suggested questions:
            </p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleSendMessage(question)}
                  className="text-xs px-3 py-1 bg-green-50 text-green-700 rounded-full hover:bg-green-100 transition-colors duration-200"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about farming..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              disabled={isTyping}
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isTyping}
              className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Quick Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg p-4 text-white">
          <Leaf className="h-6 w-6 mb-2" />
          <h3 className="font-semibold">Crop Advice</h3>
          <p className="text-sm opacity-90">Get recommendations for planting, care, and harvesting</p>
        </div>
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg p-4 text-white">
          <Droplets className="h-6 w-6 mb-2" />
          <h3 className="font-semibold">Irrigation Help</h3>
          <p className="text-sm opacity-90">Optimize watering schedules and techniques</p>
        </div>
        <div className="bg-gradient-to-r from-red-500 to-pink-600 rounded-lg p-4 text-white">
          <Bug className="h-6 w-6 mb-2" />
          <h3 className="font-semibold">Pest Control</h3>
          <p className="text-sm opacity-90">Identify and treat plant diseases and pests</p>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;