import React, { useState } from 'react';
import { Calendar, CheckCircle, Clock, AlertTriangle, Leaf, Droplets, Scissors, Package } from 'lucide-react';

const FarmingCalendar: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [cropFilter, setCropFilter] = useState('all');

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const activities = {
    0: [ // January
      { id: 1, task: 'Wheat irrigation', type: 'irrigation', crop: 'wheat', priority: 'high', status: 'pending' },
      { id: 2, task: 'Mustard flowering stage care', type: 'care', crop: 'mustard', priority: 'medium', status: 'completed' },
      { id: 3, task: 'Prepare land for spring crops', type: 'preparation', crop: 'general', priority: 'low', status: 'upcoming' },
    ],
    1: [ // February
      { id: 4, task: 'Wheat harvest preparation', type: 'harvest', crop: 'wheat', priority: 'high', status: 'upcoming' },
      { id: 5, task: 'Mustard pod formation monitoring', type: 'monitoring', crop: 'mustard', priority: 'medium', status: 'upcoming' },
      { id: 6, task: 'Summer crop land preparation', type: 'preparation', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    2: [ // March
      { id: 7, task: 'Wheat harvesting', type: 'harvest', crop: 'wheat', priority: 'high', status: 'upcoming' },
      { id: 8, task: 'Summer vegetable planting', type: 'planting', crop: 'vegetables', priority: 'high', status: 'upcoming' },
      { id: 9, task: 'Irrigation system maintenance', type: 'maintenance', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    3: [ // April
      { id: 10, task: 'Cotton land preparation', type: 'preparation', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 11, task: 'Maize sowing', type: 'planting', crop: 'maize', priority: 'high', status: 'upcoming' },
      { id: 12, task: 'Pest monitoring begins', type: 'monitoring', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    4: [ // May
      { id: 13, task: 'Cotton sowing', type: 'planting', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 14, task: 'Maize weeding', type: 'care', crop: 'maize', priority: 'medium', status: 'upcoming' },
      { id: 15, task: 'Summer irrigation intensification', type: 'irrigation', crop: 'general', priority: 'high', status: 'upcoming' },
    ],
    5: [ // June
      { id: 16, task: 'Rice nursery preparation', type: 'preparation', crop: 'rice', priority: 'high', status: 'upcoming' },
      { id: 17, task: 'Cotton pest control', type: 'care', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 18, task: 'Monsoon preparation', type: 'preparation', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    6: [ // July
      { id: 19, task: 'Rice transplanting', type: 'planting', crop: 'rice', priority: 'high', status: 'upcoming' },
      { id: 20, task: 'Sugarcane planting', type: 'planting', crop: 'sugarcane', priority: 'medium', status: 'upcoming' },
      { id: 21, task: 'Kharif crop monitoring', type: 'monitoring', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    7: [ // August
      { id: 22, task: 'Rice weeding and fertilization', type: 'care', crop: 'rice', priority: 'high', status: 'upcoming' },
      { id: 23, task: 'Cotton flowering stage care', type: 'care', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 24, task: 'Pest and disease control', type: 'care', crop: 'general', priority: 'high', status: 'upcoming' },
    ],
    8: [ // September
      { id: 25, task: 'Rice flowering stage monitoring', type: 'monitoring', crop: 'rice', priority: 'high', status: 'upcoming' },
      { id: 26, task: 'Cotton boll formation care', type: 'care', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 27, task: 'Post-monsoon field assessment', type: 'monitoring', crop: 'general', priority: 'medium', status: 'upcoming' },
    ],
    9: [ // October
      { id: 28, task: 'Rice harvesting begins', type: 'harvest', crop: 'rice', priority: 'high', status: 'upcoming' },
      { id: 29, task: 'Winter crop land preparation', type: 'preparation', crop: 'general', priority: 'medium', status: 'upcoming' },
      { id: 30, task: 'Cotton picking preparation', type: 'preparation', crop: 'cotton', priority: 'medium', status: 'upcoming' },
    ],
    10: [ // November
      { id: 31, task: 'Wheat sowing', type: 'planting', crop: 'wheat', priority: 'high', status: 'upcoming' },
      { id: 32, task: 'Cotton harvesting', type: 'harvest', crop: 'cotton', priority: 'high', status: 'upcoming' },
      { id: 33, task: 'Rice post-harvest processing', type: 'processing', crop: 'rice', priority: 'medium', status: 'upcoming' },
    ],
    11: [ // December
      { id: 34, task: 'Wheat irrigation and care', type: 'care', crop: 'wheat', priority: 'high', status: 'upcoming' },
      { id: 35, task: 'Winter vegetable planting', type: 'planting', crop: 'vegetables', priority: 'medium', status: 'upcoming' },
      { id: 36, task: 'Year-end equipment maintenance', type: 'maintenance', crop: 'general', priority: 'low', status: 'upcoming' },
    ],
  };

  const crops = ['all', 'wheat', 'rice', 'cotton', 'maize', 'vegetables', 'general'];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'planting':
        return <Leaf className="h-4 w-4" />;
      case 'irrigation':
        return <Droplets className="h-4 w-4" />;
      case 'harvest':
        return <Scissors className="h-4 w-4" />;
      case 'processing':
        return <Package className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pending':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <Clock className="h-4 w-4 text-blue-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-l-red-500 bg-red-50';
      case 'medium':
        return 'border-l-yellow-500 bg-yellow-50';
      default:
        return 'border-l-green-500 bg-green-50';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      default:
        return 'bg-blue-100 text-blue-700';
    }
  };

  const currentActivities = activities[selectedMonth as keyof typeof activities] || [];
  const filteredActivities = cropFilter === 'all' 
    ? currentActivities 
    : currentActivities.filter(activity => activity.crop === cropFilter);

  const getMonthlyStats = () => {
    const total = currentActivities.length;
    const completed = currentActivities.filter(a => a.status === 'completed').length;
    const pending = currentActivities.filter(a => a.status === 'pending').length;
    const upcoming = currentActivities.filter(a => a.status === 'upcoming').length;

    return { total, completed, pending, upcoming };
  };

  const stats = getMonthlyStats();

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Farming Calendar</h1>
        <p className="text-lg text-gray-600">Plan and track your agricultural activities throughout the year</p>
      </div>

      {/* Month Selection */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-4">
            <Calendar className="h-5 w-5 text-green-600" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="text-lg font-semibold border-0 focus:ring-0 bg-transparent"
            >
              {months.map((month, index) => (
                <option key={index} value={index}>{month}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Crop</label>
            <select
              value={cropFilter}
              onChange={(e) => setCropFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              {crops.map((crop) => (
                <option key={crop} value={crop}>{crop === 'all' ? 'All Crops' : crop.charAt(0).toUpperCase() + crop.slice(1)}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Monthly Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Activities</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <Calendar className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-yellow-500" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Upcoming</p>
              <p className="text-2xl font-bold text-blue-600">{stats.upcoming}</p>
            </div>
            <Clock className="h-8 w-8 text-blue-500" />
          </div>
        </div>
      </div>

      {/* Activities List */}
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-gray-900">
          {months[selectedMonth]} Activities {cropFilter !== 'all' && `- ${cropFilter.charAt(0).toUpperCase() + cropFilter.slice(1)}`}
        </h2>
        
        {filteredActivities.length === 0 ? (
          <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 text-center">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No activities found for the selected filters.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredActivities.map((activity) => (
              <div
                key={activity.id}
                className={`p-4 rounded-lg border-l-4 ${getPriorityColor(activity.priority)}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getActivityIcon(activity.type)}
                    <div>
                      <h3 className="font-semibold text-gray-900">{activity.task}</h3>
                      <p className="text-sm text-gray-600">
                        {activity.crop.charAt(0).toUpperCase() + activity.crop.slice(1)} • {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(activity.status)}`}>
                      {activity.status.toUpperCase()}
                    </span>
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium ${
                        activity.priority === 'high'
                          ? 'bg-red-100 text-red-700'
                          : activity.priority === 'medium'
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-green-100 text-green-700'
                      }`}
                    >
                      {activity.priority.toUpperCase()}
                    </span>
                    {getStatusIcon(activity.status)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-4 justify-center">
        <button className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors duration-200 font-medium">
          Add New Activity
        </button>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium">
          Set Reminders
        </button>
        <button className="bg-white text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200 shadow-sm border border-gray-200 font-medium">
          Export Calendar
        </button>
      </div>
    </div>
  );
};

export default FarmingCalendar;