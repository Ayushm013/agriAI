import React, { useState } from 'react';
import { Sprout, Cloud, Bug, Droplets, TrendingUp, Calendar, MessageCircle, Book } from 'lucide-react';
import Dashboard from './components/Dashboard';
import CropRecommendation from './components/CropRecommendation';
import WeatherAdvice from './components/WeatherAdvice';
import PestManagement from './components/PestManagement';
import IrrigationAdvice from './components/IrrigationAdvice';
import MarketInsights from './components/MarketInsights';
import FarmingCalendar from './components/FarmingCalendar';
import AIAssistant from './components/AIAssistant';
import ResourceLibrary from './components/ResourceLibrary';

export type ViewType = 'dashboard' | 'crops' | 'weather' | 'pests' | 'irrigation' | 'market' | 'calendar' | 'assistant' | 'resources';

function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Sprout },
    { id: 'crops', label: 'Crop Recommendations', icon: Sprout },
    { id: 'weather', label: 'Weather Advice', icon: Cloud },
    { id: 'pests', label: 'Pest Management', icon: Bug },
    { id: 'irrigation', label: 'Irrigation', icon: Droplets },
    { id: 'market', label: 'Market Insights', icon: TrendingUp },
    { id: 'calendar', label: 'Farming Calendar', icon: Calendar },
    { id: 'assistant', label: 'AI Assistant', icon: MessageCircle },
    { id: 'resources', label: 'Resources', icon: Book },
  ];

  const renderView = () => {
    switch (currentView) {
      case 'crops':
        return <CropRecommendation />;
      case 'weather':
        return <WeatherAdvice />;
      case 'pests':
        return <PestManagement />;
      case 'irrigation':
        return <IrrigationAdvice />;
      case 'market':
        return <MarketInsights />;
      case 'calendar':
        return <FarmingCalendar />;
      case 'assistant':
        return <AIAssistant />;
      case 'resources':
        return <ResourceLibrary />;
      default:
        return <Dashboard onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Sprout className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-gray-900">AgriAI</h1>
            </div>
            <nav className="hidden md:flex space-x-1">
              {navigationItems.slice(0, 5).map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.id as ViewType)}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      currentView === item.id
                        ? 'bg-green-100 text-green-700 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-white border-b border-green-100">
        <div className="flex overflow-x-auto px-4 py-2 space-x-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id as ViewType)}
                className={`flex-shrink-0 flex items-center space-x-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  currentView === item.id
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="whitespace-nowrap">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>
    </div>
  );
}

export default App;